# Dolmetsch-App – StackBlitz Start

## Schnellstart (StackBlitz)
1. Öffne https://stackblitz.com/ und melde dich an.
2. Klicke auf **Create Project** → **Import Project** und lade diese ZIP-Datei hoch.
3. Öffne im Editor die Datei `.env.example`, kopiere sie zu `.env.local` und fülle Werte aus:
   ```env
   NEXT_PUBLIC_SUPABASE_URL=
   NEXT_PUBLIC_SUPABASE_ANON_KEY=
   NEXT_PUBLIC_GOOGLE_CLIENT_ID=
   NEXT_PUBLIC_FACEBOOK_CLIENT_ID=
   NEXT_PUBLIC_APPLE_CLIENT_ID=
   NEXT_PUBLIC_APP_URL=
   ```
4. Terminal öffnen und starten:
   ```bash
   npm install
   npm run dev
   ```
5. Die Live-Preview erscheint rechts. Standard-URL ist http://localhost:3000 (StackBlitz zeigt einen Port-Preview-Link).

## Lokal (optional)
```bash
npm install
npm run dev
# oder wenn du pnpm nutzt
# pnpm install
# pnpm dev
```
